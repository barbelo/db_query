create definer = root@localhost view airline_spview as
select `query`.`airline`.`airline_ID`        AS `airline_ID`,
       `query`.`airline`.`departure_T`       AS `departure_T`,
       `query`.`airline`.`arrival_T`         AS `arrival_T`,
       `query`.`airline`.`departure_airport` AS `departure_airport`,
       `query`.`airline`.`arrival_airport`   AS `arrival_airport`
from `query`.`airline`;

