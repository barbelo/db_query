create definer = root@localhost view ticket_grpby_air as
select `query`.`ticket`.`ticket_id`  AS `ticket_id`,
       `query`.`ticket`.`airline_ID` AS `airline_ID`,
       `query`.`ticket`.`seat_id`    AS `seat_id`,
       `query`.`ticket`.`dataa_`     AS `dataa_`,
       `query`.`ticket`.`is_sale`    AS `is_sale`
from `query`.`ticket`
group by `query`.`ticket`.`airline_ID`;

