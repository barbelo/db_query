create definer = root@localhost view ticket_airline as
select `query`.`ticket`.`ticket_id`                                             AS `ticket_ID`,
       `query`.`airline`.`airline_ID`                                           AS `airline_ID`,
       `query`.`ticket`.`dataa_`                                                AS `dataa_`,
       timediff(`query`.`airline`.`arrival_T`, `query`.`airline`.`departure_T`) AS `duration`,
       `query`.`ticket`.`seat_id`                                               AS `seat_id`,
       `query`.`ticket`.`is_sale`                                               AS `is_sale`
from `query`.`ticket`
         join `query`.`airline`
where (`query`.`ticket`.`airline_ID` = `query`.`airline`.`airline_ID`);

