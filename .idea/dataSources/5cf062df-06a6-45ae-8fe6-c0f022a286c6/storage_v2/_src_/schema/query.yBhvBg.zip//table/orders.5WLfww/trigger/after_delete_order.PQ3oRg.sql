create definer = root@localhost trigger after_delete_order
    after delete
    on orders
    for each row
    update ticket
    set is_sale = true
    where ticket.ticket_id = old.ticket_id;

