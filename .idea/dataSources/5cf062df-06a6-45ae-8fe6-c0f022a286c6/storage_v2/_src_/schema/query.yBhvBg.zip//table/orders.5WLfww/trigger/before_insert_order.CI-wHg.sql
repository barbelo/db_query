create definer = root@localhost trigger before_insert_order
    before insert
    on orders
    for each row
    update ticket
    set is_sale = true
    where ticket.ticket_id = new.ticket_id;

