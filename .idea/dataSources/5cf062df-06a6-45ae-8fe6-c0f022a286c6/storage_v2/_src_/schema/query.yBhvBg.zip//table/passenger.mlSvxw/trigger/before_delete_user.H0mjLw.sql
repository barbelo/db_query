create definer = root@localhost trigger before_delete_user
    before delete
    on passenger
    for each row
    delete from orders where orders.psg_id = old.psg_id;

