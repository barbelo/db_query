create definer = root@localhost view airline_length as
select `query`.`airline`.`airline_ID`                                           AS `airline_ID`,
       timediff(`query`.`airline`.`arrival_T`, `query`.`airline`.`departure_T`) AS `duration`
from `query`.`airline`;

